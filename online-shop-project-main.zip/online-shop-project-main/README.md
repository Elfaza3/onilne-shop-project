# NAV clothing online-shop-project
## online-shop project for the OO Web Programming (CS213 ) 

## NAV clothing shop is an Online-store that sells the NAV brand.
## NAV brand is an imagenary brand which has been made by this project contributers.

## Notes About The Project:
- You can add as many products as it needs by just adding them to the products array
- 



## The contributers are:
- **Marwan Algadi, 162133**
- **Hannibal Imter, 172138**
- **Sofian Elfazaa, 162174**
- **mohamed bakosh, 171118**
