 function products(){

  return [
    {
      id: "id1",
      prodName: "custom shoe",
      prodImg: '../images/productsImages/shoe1.jpg',
      price: 39.99,
    },
    {
      id: "id2",
      prodName: "for you",
      prodImg: '../images/productsImages/shoe2.jpg',
      price: 20,
    },
    {
      id: "id3",
      prodName: "special shirt",
      prodImg: '../images/productsImages/tshirt2.png',
      price: 60,
    },
    {
      id: "id4",
      prodName: "laptop bag",
      prodImg: '../images/productsImages/bag1.jpg',
      price: 7.99,
    },
    {
      id: "id5",
      prodName: "custom bag",
      prodImg: '../images/productsImages/bag2.jpg',
      price: 42,
    },
    {
      id: "id6",
      prodName: "normal shirt",
      prodImg: '../images/productsImages/tshirt1.png',
      price: 20,
    },
    {
      id: "id7",
      prodName: "custom bag",
      prodImg: '../images/productsImages/bag3.jpg',
      price: 55,
    },
    
  ];
}

export {products};